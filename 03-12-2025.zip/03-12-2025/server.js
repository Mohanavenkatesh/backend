const app = require('./app')

const PORT = 2000

app.listen(PORT,()=>{
    console.log(`sever running at ${PORT}`);
})