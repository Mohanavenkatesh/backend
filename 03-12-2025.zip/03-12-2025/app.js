const express = require('express');

const app = express();

app.use(express.json());

const patientRoutes = require('./routes')

app.use('/patients',patientRoutes)

module.exports = app